# 1. Ricerca automatica della porta COM
Write-Host "Ricerca automatica di Arduino in corso..." -ForegroundColor Yellow

$port = $null
$foundPort = $null

foreach ($portName in [System.IO.Ports.SerialPort]::GetPortNames()) {
    try {
        $testPort = New-Object System.IO.Ports.SerialPort $portName, 9600, None, 8, One
        $testPort.ReadTimeout = 1000
        $testPort.Open()
        Start-Sleep -m 500
        $testPort.WriteLine("M")
        Start-Sleep -m 600
        $response = $testPort.ReadExisting()
        
        if ($response -like "*STATO DISPOSITIVO*" -or $response -like "*MENU*") {
            $foundPort = $portName
            $port = $testPort
            break
        }
        $testPort.Close()
    } catch {
        # Porta occupata o non valida, salta
    }
}

# Funzione per formattare e colorare il menu
function Mostra-MenuColorato ($testo) {
    Clear-Host

    $righe = $testo -split "`n"
    foreach ($riga in $righe) {
        $rigaPulita = $riga.Trim()
        
        # Ignora la riga dei tasti rapidi se inviata da Arduino
        if ($rigaPulita -like "*Comandi:*") {
            continue
        }

        # Titolo ad alto contrasto (Magenta)
        if ($rigaPulita -like "*STATO DISPOSITIVO*" -or $rigaPulita -like "*MENU*") {
            Write-Host $riga -ForegroundColor Magenta
        }
        # Separatori
        elseif ($rigaPulita -like "====*" -or $rigaPulita -like "----*") {
            Write-Host $riga -ForegroundColor DarkGray
        }
        # 1. Scorrimento principale (Verde se ON, Rosso se OFF)
        elseif ($rigaPulita -like "*Scorrimento*:*") {
            if ($rigaPulita -match "ON") { Write-Host $riga -ForegroundColor Green }
            else { Write-Host $riga -ForegroundColor Red }
        }
        # 2. Tempo Scorrimento (Sempre e solo Giallo)
        elseif ($rigaPulita -like "*Tempo Scorri*" -or $rigaPulita -like "*Tempo Scorrimento*") {
            Write-Host $riga -ForegroundColor Yellow
        }
        # 3. Standby principale (Verde se ON, Rosso se OFF)
        elseif ($rigaPulita -like "*Standby*:*") {
            if ($rigaPulita -match "ON") { Write-Host $riga -ForegroundColor Green }
            else { Write-Host $riga -ForegroundColor Red }
        }
        # 4. Tempo Standby (Sempre e solo Giallo)
        elseif ($rigaPulita -like "*Tempo Standby*") {
            Write-Host $riga -ForegroundColor Yellow
        }
        # Pagine ON/OFF e Durata
        elseif ($rigaPulita -like "*P1:*") {
            $parti = $riga -split "(\s+)"
            foreach ($p in $parti) {
                if ($p -match "\[ON") {
                    Write-Host $p -ForegroundColor Green -NoNewline
                } elseif ($p -match "\[OFF\]") {
                    Write-Host $p -ForegroundColor Red -NoNewline
                } else {
                    Write-Host $p -ForegroundColor Yellow -NoNewline
                }
            }
            Write-Host "" # Andata a capo
        }
        else {
            Write-Host $riga -ForegroundColor Yellow
        }
    }
}

# 2. Avvio dell'interfaccia interattiva
if ($port -and $port.IsOpen) {
    Mostra-MenuColorato $response

    while ($true) {
        Write-Host "`n[COMANDI: '1', '2 16', '3', '4 30', 'P1'..'P7', 'P1 10', 'P1 S', 'rtcset' | 'Q' per uscire]" -ForegroundColor Cyan
        $cmd = Read-Host "Digitare comando >"
        
        if ($cmd -eq 'Q' -or $cmd -eq 'q') { 
            Write-Host "`nChiusura connessione in corso..." -ForegroundColor Red
            break 
        }

        # Gestione comando RTCSET direttamente da PowerShell
        if ($cmd.Trim().ToLower() -eq 'rtcset') {
            $now = Get-Date
            $payload = "RTCSET $($now.Year),$($now.Month),$($now.Day),$($now.Hour),$($now.Minute),$($now.Second)"
            
            $port.WriteLine($payload)
            Start-Sleep -m 600
            $rispostaArduino = $port.ReadExisting()
            Write-Host "`n$rispostaArduino" -ForegroundColor Green
            Start-Sleep -s 1
            continue
        }
        
        $port.WriteLine($cmd)
        Start-Sleep -m 600
        $nuovoMenu = $port.ReadExisting()
        
        if ($nuovoMenu) {
            Mostra-MenuColorato $nuovoMenu
        }
    }
    $port.Close()
} else {
    Write-Host "`n[ERRORE] Impossibile trovare Arduino. Assicurati che sia collegato e che l'IDE sia chiuso." -ForegroundColor Red
}
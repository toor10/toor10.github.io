#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <RTClib.h>
#include <EEPROM.h>

#define DHTPIN 2
#define DHTTYPE DHT11
#define BTN_PAGE_PIN 7

LiquidCrystal_I2C lcd(0x27, 16, 2);
DHT dht(DHTPIN, DHTTYPE);
RTC_DS3231 rtc;

float temp = 0.0;
float hum = 0.0;

int ora = 0, minuto = 0, secondo = 0;
int giorno = 1, mese = 1, anno = 2026;
int giornoSettimana = 1;

unsigned long lastMillisDHT = 0;
unsigned long lastMillisAutoPage = 0;
unsigned long lastActivityMillis = 0;

int attualPage = 1; 
const int TOTAL_PAGES = 7; 
bool pageActiveMask[7];
int pageCustomDurations[7]; // 0 = Standard (S), >0 = Durata in secondi

bool autoRotationActive;
int pageIntervalSec;

bool standbyActive;
int standbyTimeoutSec;
bool isDisplayPowerOff = false;

bool btnLastState = HIGH;
unsigned long lastDebounceTime = 0;

const char* giorniBrevi[] = {"LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"};
const char* giorniEstesi[] = {"LUNEDI", "MARTEDI", "MERCOLEDI", "GIOVEDI", "VENERDI", "SABATO", "DOMENICA"};

// Indirizzi EEPROM
const int ADDR_MAGIC        = 0;
const int ADDR_SCORR_ON     = 1;
const int ADDR_SCORR_SEC    = 2;
const int ADDR_STANDBY_ON   = 4;
const int ADDR_STANDBY_SEC  = 5;
const int ADDR_PAGES_MASK   = 7;
const int ADDR_PAGES_DUR    = 14; // 7 * 2 byte per gli interi delle durate

// Custom Font CGRAM
byte bar1[8] = { B11100, B11110, B11110, B11110, B11110, B11110, B11110, B11100 };
byte bar2[8] = { B00111, B01111, B01111, B01111, B01111, B01111, B01111, B00111 };
byte bar3[8] = { B11111, B11111, B00000, B00000, B00000, B00000, B11111, B11111 };
byte bar4[8] = { B11110, B11100, B00000, B00000, B00000, B00000, B11000, B11100 };
byte bar5[8] = { B01111, B00111, B00000, B00000, B00000, B00000, B00011, B00111 };
byte bar6[8] = { B00000, B00000, B00000, B00000, B00000, B00000, B11111, B11111 };
byte bar7[8] = { B00000, B00000, B00000, B00000, B00000, B00000, B00111, B01111 };
byte bar8[8] = { B11111, B11111, B00000, B00000, B00000, B00000, B00000, B00000 };

void setupCustomChars() {
  lcd.createChar(1, bar1); lcd.createChar(2, bar2); lcd.createChar(3, bar3); lcd.createChar(4, bar4);
  lcd.createChar(5, bar5); lcd.createChar(6, bar6); lcd.createChar(7, bar7); lcd.createChar(8, bar8);
}

void caricaImpostazioniEEPROM() {
  if (EEPROM.read(ADDR_MAGIC) != 0x43) { // Cambio magic byte per nuova struttura
    autoRotationActive = true;
    pageIntervalSec = 10;
    standbyActive = true;
    standbyTimeoutSec = 30;
    for (int i = 0; i < TOTAL_PAGES; i++) {
      pageActiveMask[i] = true;
      pageCustomDurations[i] = 0; // 0 indica Standard
    }
    salvaImpostazioniEEPROM();
    EEPROM.update(ADDR_MAGIC, 0x43);
  } else {
    autoRotationActive = EEPROM.read(ADDR_SCORR_ON);
    EEPROM.get(ADDR_SCORR_SEC, pageIntervalSec);
    
    standbyActive = EEPROM.read(ADDR_STANDBY_ON);
    EEPROM.get(ADDR_STANDBY_SEC, standbyTimeoutSec);

    for (int i = 0; i < TOTAL_PAGES; i++) {
      pageActiveMask[i] = EEPROM.read(ADDR_PAGES_MASK + i);
      EEPROM.get(ADDR_PAGES_DUR + (i * 2), pageCustomDurations[i]);
    }
  }
}

void salvaImpostazioniEEPROM() {
  EEPROM.update(ADDR_SCORR_ON, autoRotationActive);
  EEPROM.put(ADDR_SCORR_SEC, pageIntervalSec);
  
  EEPROM.update(ADDR_STANDBY_ON, standbyActive);
  EEPROM.put(ADDR_STANDBY_SEC, standbyTimeoutSec);

  for (int i = 0; i < TOTAL_PAGES; i++) {
    EEPROM.update(ADDR_PAGES_MASK + i, pageActiveMask[i]);
    EEPROM.put(ADDR_PAGES_DUR + (i * 2), pageCustomDurations[i]);
  }
}

void setup() {
  Serial.begin(9600);
  Wire.begin();
  dht.begin();
  pinMode(BTN_PAGE_PIN, INPUT_PULLUP);

pinMode(3, OUTPUT);
digitalWrite(3, HIGH);

  lcd.init();
  lcd.backlight();
  setupCustomChars();

  caricaImpostazioniEEPROM();

  lcd.clear();
  lcd.setCursor(0, 0); lcd.print("   Benvenuto!");
  lcd.setCursor(0, 1); lcd.print("TERMOIGROMETRO");

  if (!rtc.begin()) {
    lcd.clear();
    lcd.setCursor(0, 0); lcd.print("ERRORE RTC!");
    while (1);
  }

  delay(1200);
  readSensor();
  lastActivityMillis = millis();
  lcd.clear();

  printMenuCMD();
}

void loop() {
  DateTime now = rtc.now();
  ora = now.hour(); minuto = now.minute(); secondo = now.second();
  giorno = now.day(); mese = now.month(); anno = now.year();
  giornoSettimana = now.dayOfTheWeek();
  if (giornoSettimana == 0) giornoSettimana = 7;

  if (millis() - lastMillisDHT >= 2000) {
    lastMillisDHT = millis();
    readSensor();
  }

  handleCMDInput();
  handleButtonSimple();
  checkStandbyLogic();

  // Calcolo della durata della pagina corrente (custom o standard)
  int durCorrente = pageCustomDurations[attualPage - 1];
  if (durCorrente <= 0) durCorrente = pageIntervalSec;

  if (autoRotationActive && durCorrente > 0 && !isDisplayPowerOff) {
    if (millis() - lastMillisAutoPage >= ((unsigned long)durCorrente * 1000)) {
      lastMillisAutoPage = millis();
      nextActivePage();
      lcd.clear();
    }
  }

  if (!isDisplayPowerOff) {
    displayPage(attualPage);
  }
}

void wakeUpDisplay() {
  lastActivityMillis = millis();
  if (isDisplayPowerOff) {
    isDisplayPowerOff = false;
    lcd.display();
    lcd.backlight();
    lcd.clear();
  }
}

void checkStandbyLogic() {
  if (standbyActive && standbyTimeoutSec > 0) {
    if (!isDisplayPowerOff && (millis() - lastActivityMillis >= ((unsigned long)standbyTimeoutSec * 1000))) {
      isDisplayPowerOff = true;
      lcd.clear();
      lcd.noDisplay();
      lcd.noBacklight();
    }
  }
}

void handleButtonSimple() {
  bool btnState = digitalRead(BTN_PAGE_PIN);
  if (btnState == LOW && btnLastState == HIGH) {
    if (millis() - lastDebounceTime > 200) {
      lastDebounceTime = millis();
      wakeUpDisplay();
      nextActivePage();
      lcd.clear();
    }
  }
  btnLastState = btnState;
}

void printMenuCMD() {
  Serial.println(F("\n================================="));
  Serial.println(F("        STATO DISPOSITIVO         "));
  Serial.println(F("================================="));
  
  Serial.print(F("[1] Scorrimento   : ")); 
  Serial.println(autoRotationActive ? "ON" : "OFF");
  
  Serial.print(F("[2] Tempo Scorri  : ")); 
  if (pageIntervalSec == 0) Serial.println("ND (Disattivato)"); 
  else { Serial.print(pageIntervalSec); Serial.println(" sec"); }

  Serial.print(F("[3] Standby       : ")); 
  Serial.println(standbyActive ? "ON" : "OFF");
  
  Serial.print(F("[4] Tempo Standby : ")); 
  Serial.print(standbyTimeoutSec); 
  Serial.println(" sec");

  Serial.println(F("---------------------------------"));
  Serial.println(F("Pagine ON/OFF e Durata:"));
  for (int i = 0; i < TOTAL_PAGES; i++) {
    Serial.print("P"); Serial.print(i + 1); Serial.print(":");
    if (!pageActiveMask[i]) {
      Serial.print("[OFF] ");
    } else {
      if (pageCustomDurations[i] > 0) {
        Serial.print("[ON "); Serial.print(pageCustomDurations[i]); Serial.print("s] ");
      } else {
        Serial.print("[ON S("); Serial.print(pageIntervalSec); Serial.print("s)] ");
      }
    }
  }
  Serial.println(F("\n================================="));
  Serial.println(F("Comandi: 1 | 2 | 3 | 4 | Px | Px <sec> | Px S | M | RTCSET"));
  Serial.println(F("---------------------------------\n"));
}

void handleCMDInput() {
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    input.toUpperCase();

    wakeUpDisplay();

    if (input.startsWith("RTCSET ")) {
      String dataTimeStr = input.substring(7);
      int annoVal = getValue(dataTimeStr, ',', 0).toInt();
      int meseVal = getValue(dataTimeStr, ',', 1).toInt();
      int giornoVal = getValue(dataTimeStr, ',', 2).toInt();
      int oraVal = getValue(dataTimeStr, ',', 3).toInt();
      int minutoVal = getValue(dataTimeStr, ',', 4).toInt();
      int secondoVal = getValue(dataTimeStr, ',', 5).toInt();

      if (annoVal > 2000 && meseVal > 0 && giornoVal > 0) {
        rtc.adjust(DateTime(annoVal, meseVal, giornoVal, oraVal, minutoVal, secondoVal));
        Serial.println(F("[OK] Data e ora RTC aggiornate con successo!"));
      } else {
        Serial.println(F("[ERRORE] Formato data/ora non valido."));
      }
      return;
    }

    if (input == "M" || input == "") {
      printMenuCMD();
    }
    else if (input == "1") {
      autoRotationActive = !autoRotationActive;
      salvaImpostazioniEEPROM();
      printMenuCMD();
    }
    else if (input.startsWith("2")) {
      if (input == "2") {
        if (pageIntervalSec == 5) pageIntervalSec = 10;
        else if (pageIntervalSec == 10) pageIntervalSec = 15;
        else if (pageIntervalSec == 15) pageIntervalSec = 30;
        else if (pageIntervalSec == 30) pageIntervalSec = 0;
        else pageIntervalSec = 5;
      } else {
        String valStr = input.substring(1);
        valStr.trim();
        int sec = valStr.toInt();
        pageIntervalSec = (sec < 0) ? 0 : sec;
      }
      autoRotationActive = (pageIntervalSec > 0);
      salvaImpostazioniEEPROM();
      printMenuCMD();
    }
    else if (input == "3") {
      standbyActive = !standbyActive;
      salvaImpostazioniEEPROM();
      printMenuCMD();
    }
    else if (input.startsWith("4")) {
      if (input == "4") {
        if (standbyTimeoutSec == 10) standbyTimeoutSec = 30;
        else if (standbyTimeoutSec == 30) standbyTimeoutSec = 60;
        else if (standbyTimeoutSec == 60) standbyTimeoutSec = 0;
        else standbyTimeoutSec = 10;
      } else {
        String valStr = input.substring(1);
        valStr.trim();
        int sec = valStr.toInt();
        standbyTimeoutSec = (sec < 0) ? 0 : sec;
      }
      standbyActive = (standbyTimeoutSec > 0);
      salvaImpostazioniEEPROM();
      printMenuCMD();
    }
    // Gestione Pagine: P1, P1 10, P1 S
    else if (input.startsWith("P")) {
      int spaceIdx = input.indexOf(' ');
      if (spaceIdx == -1) {
        // Tasto semplice "P1" -> Toggle ON/OFF
        int pNum = input.substring(1).toInt();
        if (pNum >= 1 && pNum <= TOTAL_PAGES) {
          pageActiveMask[pNum - 1] = !pageActiveMask[pNum - 1];
          salvaImpostazioniEEPROM();
          printMenuCMD();
        }
      } else {
        // Tasto avanzato "P1 10" o "P1 S"
        int pNum = input.substring(1, spaceIdx).toInt();
        String arg = input.substring(spaceIdx + 1);
        arg.trim();

        if (pNum >= 1 && pNum <= TOTAL_PAGES) {
          pageActiveMask[pNum - 1] = true; // Se si assegna un tempo, la si attiva in automatico
          if (arg == "S") {
            pageCustomDurations[pNum - 1] = 0; // Ripristina Standard
          } else {
            int sec = arg.toInt();
            pageCustomDurations[pNum - 1] = (sec > 0) ? sec : 0;
          }
          salvaImpostazioniEEPROM();
          printMenuCMD();
        }
      }
    }
  }
}

String getValue(String data, char separator, int index) {
  int found = 0;
  int strIndex[] = { 0, -1 };
  int maxIndex = data.length() - 1;

  for (int i = 0; i <= maxIndex && found <= index; i++) {
    if (data.charAt(i) == separator || i == maxIndex) {
      found++;
      strIndex[0] = strIndex[1] + 1;
      strIndex[1] = (i == maxIndex) ? i + 1 : i;
    }
  }
  return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

void nextActivePage() {
  for (int i = 0; i < TOTAL_PAGES; i++) {
    attualPage++;
    if (attualPage > TOTAL_PAGES) attualPage = 1;
    if (pageActiveMask[attualPage - 1]) break;
  }
}

void readSensor() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (!isnan(h) && !isnan(t) && h > 0 && t > 0) {
    hum = h; temp = t;
  }
}

void printBigNumber(int value, int col) {
  switch (value) {
    case 0: lcd.setCursor(col, 0); lcd.write(2); lcd.write(8); lcd.write(1); lcd.setCursor(col, 1); lcd.write(2); lcd.write(6); lcd.write(1); break;
    case 1: lcd.setCursor(col, 0); lcd.write(32); lcd.write(32); lcd.write(1); lcd.setCursor(col, 1); lcd.write(32); lcd.write(32); lcd.write(1); break;
    case 2: lcd.setCursor(col, 0); lcd.write(5); lcd.write(3); lcd.write(1); lcd.setCursor(col, 1); lcd.write(2); lcd.write(6); lcd.write(6); break;
    case 3: lcd.setCursor(col, 0); lcd.write(5); lcd.write(3); lcd.write(1); lcd.setCursor(col, 1); lcd.write(7); lcd.write(6); lcd.write(1); break;
    case 4: lcd.setCursor(col, 0); lcd.write(2); lcd.write(6); lcd.write(1); lcd.setCursor(col, 1); lcd.write(32); lcd.write(32); lcd.write(1); break;
    case 5: lcd.setCursor(col, 0); lcd.write(2); lcd.write(3); lcd.write(4); lcd.setCursor(col, 1); lcd.write(7); lcd.write(6); lcd.write(1); break;
    case 6: lcd.setCursor(col, 0); lcd.write(2); lcd.write(3); lcd.write(4); lcd.setCursor(col, 1); lcd.write(2); lcd.write(6); lcd.write(1); break;
    case 7: lcd.setCursor(col, 0); lcd.write(2); lcd.write(8); lcd.write(1); lcd.setCursor(col, 1); lcd.write(32); lcd.write(32); lcd.write(1); break;
    case 8: lcd.setCursor(col, 0); lcd.write(2); lcd.write(3); lcd.write(1); lcd.setCursor(col, 1); lcd.write(2); lcd.write(6); lcd.write(1); break;
    case 9: lcd.setCursor(col, 0); lcd.write(2); lcd.write(3); lcd.write(1); lcd.setCursor(col, 1); lcd.write(7); lcd.write(6); lcd.write(1); break;
  }
}

void displayPage(int pageNum) {
  switch (pageNum) {
    case 1: {
      lcd.setCursor(0, 0);
      if(giorno < 10) lcd.print("0"); lcd.print(giorno); lcd.print("/");
      if(mese < 10) lcd.print("0"); lcd.print(mese); lcd.print("/");
      lcd.print(anno); lcd.print(" ");
      if(ora < 10) lcd.print("0"); lcd.print(ora); lcd.print(":");
      if(minuto < 10) lcd.print("0"); lcd.print(minuto);

      lcd.setCursor(0, 1);
      lcd.print("TP:"); lcd.print(temp, 1); lcd.print("C");
      int hVal = (int)hum;
      if (hVal >= 100) lcd.print(" HM:100% ");
      else { lcd.print("  HM:"); lcd.print(hVal); lcd.print("% "); }
      break;
    }
    case 2: {
      lcd.setCursor(0, 0);
      lcd.print("    ");
      if(ora < 10) lcd.print("0"); lcd.print(ora); lcd.print(":");
      if(minuto < 10) lcd.print("0"); lcd.print(minuto); lcd.print(":");
      if(secondo < 10) lcd.print("0"); lcd.print(secondo);
      lcd.print("    ");

      lcd.setCursor(0, 1);
      lcd.print(" "); lcd.print(giorniBrevi[giornoSettimana - 1]); lcd.print(" ");
      if(giorno < 10) lcd.print("0"); lcd.print(giorno); lcd.print("/");
      if(mese < 10) lcd.print("0"); lcd.print(mese); lcd.print("/");
      lcd.print(anno); lcd.print(" ");
      break;
    }
    case 3: {
      lcd.setCursor(0, 0);
      if(giorno < 10) lcd.print("0"); lcd.print(giorno); lcd.print("/");
      if(mese < 10) lcd.print("0"); lcd.print(mese); lcd.print("/");
      lcd.print(anno); lcd.print(" ");
      if(ora < 10) lcd.print("0"); lcd.print(ora); lcd.print(":");
      if(minuto < 10) lcd.print("0"); lcd.print(minuto);

      lcd.setCursor(0, 1);
      lcd.print("Oggi e "); 
      lcd.print(giorniEstesi[giornoSettimana - 1]);
      lcd.print("        ");
      break;
    }
    case 4: {
      lcd.setCursor(0, 0);
      lcd.print("Temper.:["); lcd.print(temp, 1); lcd.print(" C] ");
      lcd.setCursor(0, 1);
      lcd.print("Umidita:[  "); lcd.print((int)hum); lcd.print("%  ] ");
      break;
    }
    case 5: {
      int h1 = ora / 10; int h2 = ora % 10;
      int m1 = minuto / 10; int m2 = minuto % 10;
      printBigNumber(h1, 1); printBigNumber(h2, 4);
      lcd.setCursor(7, 0); if (secondo % 2 == 0) lcd.print(":"); else lcd.print(" ");
      lcd.setCursor(7, 1); if (secondo % 2 == 0) lcd.print(":"); else lcd.print(" ");
      printBigNumber(m1, 8); printBigNumber(m2, 11);
      break;
    }
    case 6: {
      int tInt = (int)temp; int tDec = (int)(temp * 10) % 10;
      int t1 = tInt / 10; int t2 = tInt % 10;
      printBigNumber(t1, 1); printBigNumber(t2, 4);
      lcd.setCursor(7, 0); lcd.print(" "); lcd.setCursor(7, 1); lcd.print(".");
      printBigNumber(tDec, 8);
      lcd.setCursor(13, 0); lcd.print((char)223); lcd.print("T");
      lcd.setCursor(14, 1); lcd.print("C");
      break;
    }
    case 7: {
      int hVal = (int)hum;
      int h1 = hVal / 10; int h2 = hVal % 10;
      printBigNumber(h1, 3); printBigNumber(h2, 7);
      lcd.setCursor(12, 0); lcd.print("U");
      lcd.setCursor(12, 1); lcd.print("%");
      break;
    }
  }
}